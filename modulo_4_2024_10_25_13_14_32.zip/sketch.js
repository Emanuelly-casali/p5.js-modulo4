function setup() {
  createCanvas(400, 400); // criando cenário;
}

function draw() { // função de desenho
  background(220); // cor do cenário
  fill("black");// cor da letra
  textSize(64);// tamanho do texto
  textAlign(CENTER, CENTER);// centralizar o texto
  
  let maximo = width;// criando variável maximo = largura
  let minimo = 0; // criando variável minimo = 0
  //mouseX, 0, width ==> 0, palavra.length
  let palavra = "caminhante";// criando variável palavra = caminhante
  let quantidade = map(mouseX, 0, width, 1, palavra.length); //criando variável quantidade
  //console.log (quantidade);
  let parcial = palavra.substring(0, quantidade);// criando variável parcial
  text(parcial, 200, 200);// tamanho do texto parcial
  
  // if (mouseX < 50) {
  //  let palavra = "c";
  //  text(palavra, 200, 200);
  // } else if(mouseX < 100) {
  //  let palavra  = "ca";
  //  text(palavra, 200, 200);
  // } else {
  // let palavra = "caminhante";
 //}
  
  
  
}